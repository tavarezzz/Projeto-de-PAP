using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.IO;
using System.IO.Pipes;
using System.Windows.Forms;
using CsvHelper;
using CsvHelper.Configuration;
using CsvHelper.Configuration.Attributes;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static PAP_gerador_de_DOCS.Form1;
using System.IO.Compression;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolBar;
using System.IO.Packaging;
using System.Text;
using System.Security.Cryptography.X509Certificates;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using ConvertApiDotNet;
using DocumentFormat.OpenXml.Vml.Spreadsheet;
using PdfiumViewer;


namespace PAP_gerador_de_DOCS
{
    public partial class Form1 : Form
    {
        private string DocxFilename;

        PdfiumViewer.PdfViewer pdf;
        public Form1()
        {
            InitializeComponent();
            pdf = new PdfViewer();
            pdf.Width = this.panel1.Width - 5;
            pdf.Width = this.panel1.Width - 5;
            this.panel1.Controls.Add(pdf);
           
        }


        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.ShowDialog();

            DataTable table = new DataTable();
            using (StreamReader reader = new StreamReader(dlg.FileName))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    string[] values = line.Split(';');
                    if (table.Columns.Count == 0)
                    {
                        foreach (string header in values)
                        {
                            table.Columns.Add(header);
                        }
                    }
                    else
                    {
                        table.Rows.Add(values);
                    }
                }
            }
            dataGridView1.DataSource = table;

        }


        public class infos
        {

            public string Name { get; set; }

            public string numero { get; set; }

            public string email { get; set; }

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }


        async void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                //(dialog.FileName); 
                var convertApi = new ConvertApi("SBI89EI1sEhRUBcO");
                var convert = await convertApi.ConvertAsync("docx", "pdf",
                new ConvertApiFileParam("File", dialog.FileName)
                );
                await convert.SaveFilesAsync(@"C:\Users\Utilizador\Documents");

                openfile(dialog.FileName.Replace(".docx",".pdf"));
            }
            DocxFilename = dialog.FileName;
        }

        public void openfile(string filepath)
        {
            byte[] bytes = System.IO.File.ReadAllBytes(filepath);
            var stream = new System.IO.MemoryStream(bytes);
            PdfDocument pdfDocument = PdfDocument.Load(stream);
            pdf.Document = pdfDocument;


        }


        public void button1_Click(object sender, EventArgs e)
        {

            string tempDirectory = Path.Combine(Path.GetTempPath(), Path.GetRandomFileName());
            Directory.CreateDirectory(tempDirectory);

            MessageBox.Show("Pasta tempor�ria criada com sucesso: " + tempDirectory);

            

            string zipFilePath = DocxFilename;

            string extractPath = tempDirectory;

            ZipFile.ExtractToDirectory(DocxFilename, tempDirectory);




            string pastaParaComprimir = tempDirectory;

            // Define o caminho para o arquivo ZIP que ser� criado
            string arquivoZip = @"C:\Users\Utilizador\Documents\XPTO.DOCX";

            // Cria o arquivo ZIP e adiciona a pasta e seus arquivos
            ZipFile.CreateFromDirectory(pastaParaComprimir, arquivoZip);

            // Verifica se o arquivo ZIP foi criado com sucesso
           


            //Directory.Delete(tempDirectory, recursive: true);
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        } 

    }
















    //Comprimir o Docx


    public class Comprimir_Docx
    {
        private static string directoryPath = "  ";
        public static void main()
        {
            DirectoryInfo directorySelected = new DirectoryInfo(directoryPath);
            Compress(directorySelected);

            foreach (FileInfo fileToDecompress in directorySelected.GetFiles("*.gz"))
            {
                Decompress(fileToDecompress);
            }
        }

        public static void Compress(DirectoryInfo directorySelected)
        {
            foreach (FileInfo fileToCompress in directorySelected.GetFiles())
            {
                using (FileStream originalFileStream = fileToCompress.OpenRead())
                {
                    if ((File.GetAttributes(fileToCompress.FullName) &
                       FileAttributes.Hidden) != FileAttributes.Hidden & fileToCompress.Extension != ".gz")
                    {
                        using (FileStream compressedFileStream = File.Create(fileToCompress.FullName + ".gz"))
                        {
                            using (GZipStream compressionStream = new GZipStream(compressedFileStream,
                               CompressionMode.Compress))
                            {
                                originalFileStream.CopyTo(compressionStream);
                            }
                        }
                        FileInfo info = new FileInfo(directoryPath + Path.DirectorySeparatorChar + fileToCompress.Name + ".gz");
                        Console.WriteLine($"Compressed {fileToCompress.Name} from {fileToCompress.Length.ToString()} to {info.Length.ToString()} bytes.");
                    }
                }
            }
        }

        public static void Decompress(FileInfo fileToDecompress)
        {
            using (FileStream originalFileStream = fileToDecompress.OpenRead())
            {
                string currentFileName = fileToDecompress.FullName;
                string newFileName = currentFileName.Remove(currentFileName.Length - fileToDecompress.Extension.Length);

                using (FileStream decompressedFileStream = File.Create(newFileName))
                {
                    using (GZipStream decompressionStream = new GZipStream(originalFileStream, CompressionMode.Decompress))
                    {
                        decompressionStream.CopyTo(decompressedFileStream);
                        Console.WriteLine($"Decompressed: {fileToDecompress.Name}");
                    }
                }
            }
        }
    }
}